# Student Management System

A responsive front-end mini-project built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and student form/table
- `style.css` — responsive styling
- `script.js` — add, edit, delete, search, filtering, statistics, and Local Storage

## Run the project
1. Extract the ZIP file.
2. Open the `student_management_system` folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

No backend or installation is required. Student records are saved in the browser's Local Storage for this browser and origin.

## Features
- Add student records with validation
- Prevent duplicate student IDs
- Edit and delete records
- Search by name, ID, course, or contact details
- Filter by course
- Dashboard statistics for student count, course count, and average marks
- Responsive layout for desktop and mobile
- Sample data on first launch

## Teaching note
This is a front-end learning demo, not a secure production system. Local Storage is device/browser-specific and should not be used for sensitive real student records.
